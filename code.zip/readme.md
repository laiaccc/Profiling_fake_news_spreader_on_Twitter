Profiling fake news spreaders from twitter
The programmes here aimed at traning various meachine learning models such as AdaBoost, Random Forest, Logistic Regression and Support Vector Machines.
The file features.py contains the dataframe of 18 artifitially generated features from the dataset.


Prerequisites:
pip install spaCy package in Python, version 2.2.4
pip install a spaCy English module in Python, en_core_web_sm, version 2.2.5
pip install lexical-diversity module in Python, version 0.1.1
pip install textblob package in Python, version 0.15.3

Python modules used:
regex 2.2.1
numpy  1.18.1
pandas 1.0.0
nltk 3.4.4
nltk stopwords dictionary: english
keras 2.3.1

Python version:
Python 3.7.6

LSTM:
Running on Google colab